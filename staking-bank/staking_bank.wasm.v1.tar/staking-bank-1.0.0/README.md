## Staking bank contract

The staking bank is a decentralised registry of validators.

Setup addresses in bank by providing public key as `number[]`. 

Use https://cryptii.com/pipes/integer-encoder